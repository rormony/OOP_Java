/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USER
 */
public class Showtime {
    String time;
    String date;
    int hallNumber;
    Movie movie;

    public Showtime(String time, String date , int hallNumber, Movie[] movies){
        this.time = time;
        this.date = date;
        this.hallNumber = hallNumber;
        this.movie = movie;
    }
}
