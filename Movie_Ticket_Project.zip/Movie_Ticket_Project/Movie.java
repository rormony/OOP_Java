public class Movie{
    int id;
    String title;
    double duration;
    String releaseDate;
    double price;
    



    public Movie(int id, String title, double duration, String releaseDate){
        this.id = id;
        this.title = title;
        this.duration = duration;
        this.releaseDate = releaseDate;
    }
    
}